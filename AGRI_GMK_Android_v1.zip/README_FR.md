# AGRI GMK — Version Android 1.0

Application de gestion agricole pour le suivi des cocotiers et manguiers au Togo.

## Contenu de cette première version
- Tableau de bord
- 200 cocotiers C001 à C200
- 100 manguiers M001 à M100
- Fiches individuelles
- Ajout de traitements
- Rubriques irrigation, récoltes, ventes et rapports
- Interface Android en français

## Créer l'APK
1. Installer Android Studio sur un ordinateur.
2. Ouvrir le dossier `AGRI_GMK_Android`.
3. Laisser Android Studio télécharger les composants Gradle/Android nécessaires.
4. Choisir `Build > Build APK(s)`.
5. L'APK sera généré dans `app/build/outputs/apk/debug/`.

Cette version est une base fonctionnelle de démonstration. La prochaine étape peut ajouter une vraie base de données, le plan GPS du terrain, les photos des arbres, les comptes utilisateurs et la synchronisation en ligne.
