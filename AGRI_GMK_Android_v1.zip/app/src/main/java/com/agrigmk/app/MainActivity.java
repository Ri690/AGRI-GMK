package com.agrigmk.app;

import android.app.*;
import android.os.Bundle;
import android.graphics.Color;
import android.content.*;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout root, content;
    final int GREEN=Color.rgb(23,138,59), DARK=Color.rgb(11,93,42), ORANGE=Color.rgb(235,145,30);

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        showHome();
    }

    TextView title(String s, int size){
        TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(DARK);
        t.setPadding(16,16,16,10); return t;
    }
    Button nav(String s, final View.OnClickListener l){
        Button b=new Button(this); b.setText(s); b.setOnClickListener(l);
        b.setAllCaps(false); b.setTextColor(Color.WHITE); b.setBackgroundColor(GREEN);
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,60,1); p.setMargins(4,4,4,4); b.setLayoutParams(p); return b;
    }
    void base(String screen){
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(Color.WHITE);
        TextView bar=title("AGRI GMK   •   "+screen,20); bar.setTextColor(Color.WHITE); bar.setBackgroundColor(DARK);
        root.addView(bar,new LinearLayout.LayoutParams(-1,64));
        content=new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL); content.setPadding(12,8,12,8);
        ScrollView sc=new ScrollView(this); sc.addView(content); root.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout navs=new LinearLayout(this); navs.setBackgroundColor(DARK);
        navs.addView(nav("Accueil",v->showHome())); navs.addView(nav("Cocotiers",v->showTrees("Cocotiers",200,"C")));
        navs.addView(nav("Manguiers",v->showTrees("Manguiers",100,"M"))); navs.addView(nav("Plus",v->showMore()));
        root.addView(navs,new LinearLayout.LayoutParams(-1,68)); setContentView(root);
    }
    TextView card(String s){
        TextView t=title(s,16); t.setBackgroundColor(Color.rgb(239,248,241));
        t.setPadding(18,18,18,18); LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,90); p.setMargins(0,7,0,7); t.setLayoutParams(p); return t;
    }
    void showHome(){
        base("Tableau de bord");
        content.addView(title("Bienvenue dans AGRI GMK 🌴🥭",24));
        content.addView(card("🌴 200 cocotiers\nSuivi individuel C001 à C200"));
        content.addView(card("🥭 100 manguiers\nSuivi individuel M001 à M100"));
        content.addView(card("💊 Traitements\nEnregistrer produit, date, arbre/parcelle et prochaine intervention"));
        content.addView(card("🌾 Récoltes\nQuantités de noix de coco et de mangues"));
        content.addView(card("💰 Ventes\nProduits, quantités, prix, clients et recettes"));
        content.addView(card("📊 Rapports\nProduction, dépenses, ventes et bénéfice"));
    }
    void showTrees(String name,int count,String prefix){
        base(name);
        TextView info=title(count+" arbres • recherche et suivi",18); content.addView(info);
        EditText search=new EditText(this); search.setHint("Rechercher un numéro, ex. "+prefix+"001"); content.addView(search);
        LinearLayout list=new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL); content.addView(list);
        for(int i=1;i<=count;i++){
            final String id=prefix+String.format("%03d",i);
            Button b=new Button(this); b.setText(id+"   •   Parcelle A   •   En bonne santé"); b.setAllCaps(false);
            b.setOnClickListener(v->showTreeDetail(id,name)); list.addView(b);
        }
    }
    void showTreeDetail(String id,String type){
        base("Fiche "+id);
        content.addView(title(id+" — "+type,24));
        content.addView(card("📍 Parcelle : A\nÉtat : En bonne santé"));
        content.addView(card("📅 Date de plantation : à renseigner"));
        content.addView(card("🌱 Variété : à renseigner"));
        content.addView(card("💊 Dernier traitement : à renseigner"));
        content.addView(card("🌾 Dernière récolte : à renseigner"));
        Button add=new Button(this); add.setText("＋ Ajouter une intervention"); add.setOnClickListener(v->showTreatment(id));
        content.addView(add);
    }
    void showTreatment(String id){
        base("Nouveau traitement");
        content.addView(title("Traitement de "+id,22));
        EditText produit=new EditText(this); produit.setHint("Produit utilisé"); content.addView(produit);
        EditText qty=new EditText(this); qty.setHint("Quantité"); content.addView(qty);
        EditText date=new EditText(this); date.setHint("Date du traitement"); content.addView(date);
        EditText next=new EditText(this); next.setHint("Prochaine intervention"); content.addView(next);
        Button save=new Button(this); save.setText("Enregistrer"); save.setOnClickListener(v->{
            Toast.makeText(this,"Traitement enregistré pour "+id,Toast.LENGTH_LONG).show(); showTreeDetail(id,"Plantation");
        }); content.addView(save);
    }
    void showMore(){
        base("Gestion agricole");
        Button irrigation=new Button(this); irrigation.setText("💧 Irrigation / Forage / Réservoir"); irrigation.setOnClickListener(v->showSimple("Irrigation","Forage principal\nNiveau d'eau : à renseigner\nPompe : à renseigner\nRéservoir : à renseigner")); content.addView(irrigation);
        Button harvest=new Button(this); harvest.setText("🌾 Récoltes"); harvest.setOnClickListener(v->showSimple("Récoltes","Ajouter noix de coco ou mangues récoltées, quantité, date et parcelle.")); content.addView(harvest);
        Button sales=new Button(this); sales.setText("💰 Ventes"); sales.setOnClickListener(v->showSimple("Ventes","Ajouter produit, quantité, prix, client et montant encaissé.")); content.addView(sales);
        Button reports=new Button(this); reports.setText("📊 Rapports"); reports.setOnClickListener(v->showSimple("Rapports","Production annuelle\nVentes\nDépenses\nBénéfice")); content.addView(reports);
    }
    void showSimple(String title,String body){
        base(title); content.addView(title(body,18));
        Button add=new Button(this); add.setText("＋ Ajouter"); add.setOnClickListener(v->Toast.makeText(this,"Fonction prête à être complétée",Toast.LENGTH_SHORT).show()); content.addView(add);
    }
}
